export { default } from './ConfigMenu';
