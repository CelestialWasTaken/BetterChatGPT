export { default } from './ShareGPT';
