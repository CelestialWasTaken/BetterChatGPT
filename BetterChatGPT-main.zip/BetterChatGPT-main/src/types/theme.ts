export type Theme = 'light' | 'dark';
